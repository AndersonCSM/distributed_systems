/**
 * 🎵 Player de Música — Dia das Mães
 * Controla reprodução de áudio com botão play/mute
 */

(function () {
  'use strict';

  // ============================================================
  // 🔧 CONFIGURAÇÃO: Substitua a URL abaixo pelo link da música
  // ============================================================
  const MUSIC_URL = 'https://youtu.be/uAoYJChWqKw'; // Ex: 'assets/audio/musica.mp3' ou URL externa

  let audio = null;
  let isPlaying = false;
  let musicBtn = null;
  let iconEl = null;

  function init() {
    musicBtn = document.getElementById('music-btn');
    iconEl = musicBtn ? musicBtn.querySelector('.music-btn__icon') : null;

    if (!musicBtn) return;

    // Create audio element
    audio = new Audio();
    audio.loop = true;
    audio.volume = 0.5;
    audio.preload = 'auto';

    if (MUSIC_URL) {
      audio.src = MUSIC_URL;
    }

    // Events
    musicBtn.addEventListener('click', toggleMusic);

    // Audio events
    audio.addEventListener('play', () => updateUI(true));
    audio.addEventListener('pause', () => updateUI(false));
    audio.addEventListener('error', () => {
      console.warn('Música não carregada. Verifique o link.');
      updateUI(false);
    });
  }

  function toggleMusic() {
    if (!audio) return;

    if (!audio.src || audio.src === window.location.href) {
      // No source set — show friendly message
      console.info('🎵 Nenhuma música configurada. Defina MUSIC_URL no player.js');
      animateButton();
      return;
    }

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch((err) => {
        console.warn('Reprodução bloqueada pelo navegador:', err.message);
      });
    }
  }

  function updateUI(playing) {
    isPlaying = playing;

    if (!musicBtn || !iconEl) return;

    if (playing) {
      musicBtn.classList.add('playing');
      iconEl.textContent = '🔊';
      musicBtn.setAttribute('aria-label', 'Pausar música');
      musicBtn.title = 'Pausar música';
    } else {
      musicBtn.classList.remove('playing');
      iconEl.textContent = '🎵';
      musicBtn.setAttribute('aria-label', 'Tocar música');
      musicBtn.title = 'Tocar música';
    }
  }

  function animateButton() {
    if (!musicBtn) return;
    musicBtn.style.transform = 'scale(1.2)';
    setTimeout(() => { musicBtn.style.transform = ''; }, 200);
  }

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
