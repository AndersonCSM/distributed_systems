import pg from "pg";

const { Pool } = pg;

const pool = new Pool({
  host: process.env.DB_HOST,
  port: 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: { rejectUnauthorized: false }
});

async function criarTabelaSeNaoExistir() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS temperaturas (
      id SERIAL PRIMARY KEY,
      temperatura NUMERIC(5,2) NOT NULL,
      origem VARCHAR(50),
      criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);
}

export const handler = async (event) => {
  try {
    await criarTabelaSeNaoExistir();

    const method =
      event?.requestContext?.http?.method ||
      event?.httpMethod ||
      "GET";

    if (method === "POST") {
      const body = typeof event.body === "string"
        ? JSON.parse(event.body || "{}")
        : event.body || {};

      if (body.temperatura === undefined) {
        return resposta(400, { erro: "Campo temperatura é obrigatório" });
      }

      const result = await pool.query(
        "INSERT INTO temperaturas (temperatura, origem) VALUES ($1, $2) RETURNING *",
        [body.temperatura, body.origem || "ESP32-Wokwi"]
      );

      return resposta(201, {
        mensagem: "Temperatura gravada com sucesso",
        dado: result.rows[0]
      });
    }

    if (method === "GET") {
      const result = await pool.query(
        "SELECT * FROM temperaturas ORDER BY criado_em DESC LIMIT 20"
      );

      return resposta(200, result.rows);
    }

    if (method === "OPTIONS") {
      return resposta(200, { mensagem: "OK" });
    }

    return resposta(405, { erro: "Método não permitido" });
  } catch (error) {
    return resposta(500, { erro: "Erro interno na Lambda", detalhe: error.message });
  }
};

function resposta(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}
