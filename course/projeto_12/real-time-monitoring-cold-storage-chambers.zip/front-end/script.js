// Configurações da API (Usando a sua URL e Token, os mesmos do ESP32)
const API_URL = "https://e21pyt0wv2.execute-api.us-east-1.amazonaws.com/prod/temperaturas";
const AUTH_TOKEN = "ANDERSONCARLOS";

// Configurações de limite para a Câmara Fria
// Valores fora deste intervalo (em °C) entrarão em status de "Atenção"
const MIN_TEMP = 2.0;
const MAX_TEMP = 8.0;

document.addEventListener("DOMContentLoaded", () => {
    // Busca os dados iniciais assim que carregar a página
    fetchData();

    // Atualiza os dados a cada 30 segundos
    setInterval(fetchData, 30000);
});

async function fetchData() {
    try {
        const response = await fetch(API_URL, {
            method: "GET",
            headers: {
                "Authorization": AUTH_TOKEN,
                "Content-Type": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error(`Erro na API: ${response.status}`);
        }

        const data = await response.json();

        // Verifica se há dados para exibir
        if (data && data.length > 0) {
            updateDashboard(data);
        } else {
            showEmptyState();
        }
    } catch (error) {
        console.error("Erro ao buscar dados:", error);
        showErrorState();
    }
}

function updateDashboard(data) {
    // A última leitura é o primeiro item (assumindo que a API retorna ordenado desc)
    const latest = data[0];

    // Atualiza o Painel Principal
    const tempValue = parseFloat(latest.temperatura);
    document.getElementById('lastTemp').textContent = tempValue.toFixed(2);
    document.getElementById('originText').textContent = latest.origem || "Desconhecida";

    // Formata a Data/Hora
    const dateObj = new Date(latest.criado_em);
    document.getElementById('timeText').textContent = dateObj.toLocaleString('pt-BR');

    // Verifica o Status baseado nos limites (MIN_TEMP e MAX_TEMP)
    const isNormal = tempValue >= MIN_TEMP && tempValue <= MAX_TEMP;

    const statusIndicator = document.getElementById('statusIndicator');
    const statusText = document.getElementById('statusText');

    if (isNormal) {
        statusText.textContent = "Normal";
        statusText.className = "value status-normal";
        statusIndicator.className = "status-indicator bg-normal live-pulse";
    } else {
        statusText.textContent = "Atenção";
        statusText.className = "value status-warning";
        statusIndicator.className = "status-indicator bg-warning live-pulse";
    }

    // Atualiza a Tabela de Histórico
    const tbody = document.getElementById('historyBody');
    tbody.innerHTML = ''; // Limpa a tabela atual

    data.forEach(item => {
        const tr = document.createElement('tr');

        const itemTemp = parseFloat(item.temperatura);
        const itemNormal = itemTemp >= MIN_TEMP && itemTemp <= MAX_TEMP;

        const statusLabel = itemNormal ? "Normal" : "Atenção";
        const statusClass = itemNormal ? "status-normal" : "status-warning";

        // Formatar data
        const itemDate = new Date(item.criado_em).toLocaleString('pt-BR');

        tr.innerHTML = `
            <td>${itemDate}</td>
            <td>${itemTemp.toFixed(2)} °C</td>
            <td>${item.origem || "-"}</td>
            <td class="${statusClass}" style="font-weight: 600;">${statusLabel}</td>
        `;

        tbody.appendChild(tr);
    });
}

function showEmptyState() {
    document.getElementById('lastTemp').textContent = "--";
    document.getElementById('statusText').textContent = "Sem Dados";
    document.getElementById('statusText').className = "value";
    document.getElementById('statusIndicator').className = "status-indicator";

    document.getElementById('historyBody').innerHTML = `
        <tr>
            <td colspan="4" style="text-align: center; color: var(--text-muted);">Nenhum registro encontrado.</td>
        </tr>
    `;
}

function showErrorState() {
    document.getElementById('statusText').textContent = "Erro de Conexão";
    document.getElementById('statusText').className = "value status-warning";
    document.getElementById('statusIndicator').className = "status-indicator bg-warning";
}
