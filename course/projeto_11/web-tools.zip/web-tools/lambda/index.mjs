/**
 * Web Tools — Lambda: Conversor Markdown → PDF
 * Runtime: Node.js 20.x (ES Modules)
 *
 * Endpoints:
 *   POST /convert         → Recebe MD/TXT, converte para PDF, salva no S3
 *   GET  /files            → Lista PDFs no bucket
 *   GET  /files/{filename} → Retorna PDF específico para download
 */

import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  ListObjectsV2Command,
} from '@aws-sdk/client-s3';
import { marked } from 'marked';
import PDFDocument from 'pdfkit';

// ============================================
// Config
// ============================================
const BUCKET_NAME = process.env.BUCKET_NAME || 'web-tools-pdfs-anderson';
const REGION = process.env.AWS_REGION || 'us-east-1';
const s3 = new S3Client({ region: REGION });

// CORS headers — ajuste a origin para seu domínio Amplify
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS',
};

// ============================================
// Main Handler
// ============================================
export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event));

  const method = event.httpMethod || event.requestContext?.http?.method;
  const path = event.path || event.rawPath || '';

  // Preflight CORS
  if (method === 'OPTIONS') {
    return response(200, { message: 'OK' });
  }

  try {
    // POST /convert — Upload e conversão
    if (method === 'POST' && path.includes('/convert')) {
      return await handleConvert(event);
    }

    // GET /files/{filename} — Download de PDF específico
    if (method === 'GET' && path.includes('/files/')) {
      const filename = decodeURIComponent(path.split('/files/')[1]);
      return await handleDownload(filename);
    }

    // GET /files — Listar PDFs
    if (method === 'GET' && path.includes('/files')) {
      return await handleList();
    }

    // GET /health — Health check
    if (method === 'GET' && path.includes('/health')) {
      return response(200, { status: 'ok', timestamp: new Date().toISOString() });
    }

    return response(404, { error: 'Rota não encontrada', debug: { method, path, rawPath: event.rawPath, resource: event.resource, pathParams: event.pathParameters } });
  } catch (err) {
    console.error('Handler error:', err);
    return response(500, { error: 'Erro interno', details: err.message });
  }
};

// ============================================
// POST /convert — Converter MD → PDF
// ============================================
async function handleConvert(event) {
  const body = JSON.parse(event.body || '{}');
  const { filename, content } = body;

  if (!filename || !content) {
    return response(400, { error: 'Campos "filename" e "content" são obrigatórios' });
  }

  // Nome do PDF de saída
  const pdfFilename = filename.replace(/\.(md|txt|markdown)$/i, '.pdf');

  // Converter Markdown → tokens estruturados
  const tokens = marked.lexer(content);

  // Gerar PDF com PDFKit
  const pdfBuffer = await generatePDF(tokens, content);

  // Upload para S3
  await s3.send(new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: pdfFilename,
    Body: pdfBuffer,
    ContentType: 'application/pdf',
  }));

  console.log(`PDF salvo: ${pdfFilename} (${pdfBuffer.length} bytes)`);

  return response(200, {
    message: 'PDF gerado com sucesso!',
    filename: pdfFilename,
    size: pdfBuffer.length,
  });
}

// ============================================
// GET /files — Listar PDFs no S3
// ============================================
async function handleList() {
  const result = await s3.send(new ListObjectsV2Command({
    Bucket: BUCKET_NAME,
    Prefix: '',
  }));

  const files = (result.Contents || [])
    .filter((obj) => obj.Key.endsWith('.pdf'))
    .map((obj) => ({
      name: obj.Key,
      size: obj.Size,
      date: obj.LastModified?.toISOString(),
    }));

  return response(200, { files, count: files.length });
}

// ============================================
// GET /files/{filename} — Download de PDF
// ============================================
async function handleDownload(filename) {
  try {
    const result = await s3.send(new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: filename,
    }));

    // Converter stream para buffer
    const chunks = [];
    for await (const chunk of result.Body) {
      chunks.push(chunk);
    }
    const buffer = Buffer.concat(chunks);

    return response(200, {
      filename: filename,
      data: buffer.toString('base64'),
    });
  } catch (err) {
    if (err.name === 'NoSuchKey') {
      return response(404, { error: `Arquivo "${filename}" não encontrado` });
    }
    throw err;
  }
}

// ============================================
// Gerador de PDF com PDFKit
// ============================================
async function generatePDF(tokens, rawContent) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margins: { top: 60, bottom: 60, left: 55, right: 55 },
      info: {
        Title: 'Documento Convertido — Web Tools',
        Author: 'Web Tools Converter',
        Creator: 'Web Tools Lambda',
      },
    });

    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // --- Estilos ---
    const STYLES = {
      h1: { size: 24, font: 'Helvetica-Bold', color: '#1a1a2e', spacing: 16 },
      h2: { size: 20, font: 'Helvetica-Bold', color: '#16213e', spacing: 14 },
      h3: { size: 16, font: 'Helvetica-Bold', color: '#0f3460', spacing: 12 },
      h4: { size: 14, font: 'Helvetica-Bold', color: '#333333', spacing: 10 },
      body: { size: 11, font: 'Helvetica', color: '#2d2d2d', spacing: 6 },
      code: { size: 10, font: 'Courier', color: '#c0392b', spacing: 4 },
      codeBlock: { size: 9.5, font: 'Courier', color: '#2d2d2d', bg: '#f4f4f4', spacing: 8 },
      listItem: { size: 11, font: 'Helvetica', color: '#2d2d2d', spacing: 4 },
      hr: { color: '#cccccc' },
    };

    // --- Header decorativo ---
    doc.rect(0, 0, doc.page.width, 6).fill('#6366f1');

    doc.moveDown(0.5);

    // --- Renderizar tokens ---
    for (const token of tokens) {
      renderToken(doc, token, STYLES);
    }

    // --- Footer ---
    const footerText = `Gerado por Web Tools — ${new Date().toLocaleDateString('pt-BR')}`;
    doc.fontSize(8).fillColor('#999999').text(footerText, 55, doc.page.height - 40, {
      align: 'center',
      width: doc.page.width - 110,
    });

    doc.end();
  });
}

function renderToken(doc, token, STYLES) {
  switch (token.type) {
    case 'heading': {
      const style = STYLES[`h${token.depth}`] || STYLES.h4;
      doc.moveDown(0.8);
      doc.font(style.font).fontSize(style.size).fillColor(style.color);
      doc.text(cleanInlineTokens(token.text), { lineGap: style.spacing });
      doc.moveDown(0.3);
      break;
    }

    case 'paragraph': {
      doc.font(STYLES.body.font).fontSize(STYLES.body.size).fillColor(STYLES.body.color);
      doc.text(cleanInlineTokens(token.text), { lineGap: STYLES.body.spacing, align: 'justify' });
      doc.moveDown(0.5);
      break;
    }

    case 'code': {
      const s = STYLES.codeBlock;
      doc.moveDown(0.3);
      const startY = doc.y;
      const textWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;

      // Medir altura do texto
      const textHeight = doc.font(s.font).fontSize(s.size).heightOfString(token.text, {
        width: textWidth - 20,
      });

      // Fundo cinza
      doc.rect(doc.page.margins.left, startY, textWidth, textHeight + 16)
        .fill(s.bg);

      // Texto do código
      doc.fillColor(s.color).font(s.font).fontSize(s.size);
      doc.text(token.text, doc.page.margins.left + 10, startY + 8, {
        width: textWidth - 20,
        lineGap: s.spacing,
      });

      doc.moveDown(0.6);
      break;
    }

    case 'list': {
      for (const item of token.items || []) {
        const bullet = token.ordered ? `${(token.items.indexOf(item) + 1)}.` : '•';
        doc.font(STYLES.listItem.font)
          .fontSize(STYLES.listItem.size)
          .fillColor(STYLES.listItem.color);
        doc.text(`  ${bullet}  ${cleanInlineTokens(item.text)}`, {
          lineGap: STYLES.listItem.spacing,
          indent: 15,
        });
      }
      doc.moveDown(0.4);
      break;
    }

    case 'blockquote': {
      doc.moveDown(0.3);
      const x = doc.page.margins.left;
      const y = doc.y;

      // Barra lateral azul
      doc.rect(x, y, 3, 20).fill('#6366f1');

      doc.font('Helvetica-Oblique').fontSize(11).fillColor('#555555');
      const quoteText = token.tokens?.map((t) => cleanInlineTokens(t.text || '')).join(' ') || '';
      doc.text(quoteText, x + 15, y, { lineGap: 6 });
      doc.moveDown(0.5);
      break;
    }

    case 'hr': {
      doc.moveDown(0.5);
      const hrY = doc.y;
      const hrWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
      doc.moveTo(doc.page.margins.left, hrY)
        .lineTo(doc.page.margins.left + hrWidth, hrY)
        .strokeColor(STYLES.hr.color)
        .lineWidth(0.5)
        .stroke();
      doc.moveDown(0.5);
      break;
    }

    case 'space': {
      doc.moveDown(0.3);
      break;
    }

    default:
      // Tokens não suportados — renderizar como texto simples
      if (token.text) {
        doc.font(STYLES.body.font).fontSize(STYLES.body.size).fillColor(STYLES.body.color);
        doc.text(cleanInlineTokens(token.text), { lineGap: STYLES.body.spacing });
        doc.moveDown(0.3);
      }
      break;
  }
}

/**
 * Remove marcação inline (bold, italic, links, code) para texto limpo
 */
function cleanInlineTokens(text) {
  if (!text) return '';
  return text
    .replace(/\*\*(.*?)\*\*/g, '$1')    // bold
    .replace(/\*(.*?)\*/g, '$1')          // italic
    .replace(/`(.*?)`/g, '$1')            // inline code
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')   // links
    .replace(/~~(.*?)~~/g, '$1');         // strikethrough
}

// ============================================
// Helpers
// ============================================
function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      ...CORS_HEADERS,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  };
}
