/**
 * Web Tools — Conversor Markdown → PDF
 * Front-end application logic
 */

(() => {
  'use strict';

  // ============================================
  // Configuration
  // ============================================
  const CONFIG = {
    // TODO: Replace with your actual API Gateway endpoint after deploy
    API_BASE_URL: 'https://api-web-tools.anderson.grupo5.sd.ufersa.dev.br',
    MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB (API Gateway limit)
    ALLOWED_EXTENSIONS: ['.md', '.txt', '.markdown'],
    TOAST_DURATION: 4000,
  };

  // ============================================
  // DOM Elements
  // ============================================
  const $ = (sel) => document.querySelector(sel);
  const dom = {
    dropzone: $('#dropzone'),
    fileInput: $('#fileInput'),
    filePreview: $('#filePreview'),
    fileName: $('#fileName'),
    fileSize: $('#fileSize'),
    removeFile: $('#removeFile'),
    uploadBtn: $('#uploadBtn'),
    uploadBtnText: $('#uploadBtnText'),
    uploadSpinner: $('#uploadSpinner'),
    progressBar: $('#progressBar'),
    progressFill: $('#progressFill'),
    refreshBtn: $('#refreshBtn'),
    refreshBtnText: $('#refreshBtnText'),
    refreshSpinner: $('#refreshSpinner'),
    pdfList: $('#pdfList'),
    toastContainer: $('#toastContainer'),
    statusBadge: $('#statusBadge'),
  };

  // ============================================
  // State
  // ============================================
  let selectedFile = null;

  // ============================================
  // Utilities
  // ============================================
  function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
  }

  function getFileExtension(name) {
    return name.substring(name.lastIndexOf('.')).toLowerCase();
  }

  function isValidFile(file) {
    const ext = getFileExtension(file.name);
    if (!CONFIG.ALLOWED_EXTENSIONS.includes(ext)) {
      showToast('Formato inválido. Envie arquivos .md ou .txt', 'error');
      return false;
    }
    if (file.size > CONFIG.MAX_FILE_SIZE) {
      showToast('Arquivo excede o limite de 10MB', 'error');
      return false;
    }
    return true;
  }

  // ============================================
  // Toast Notifications
  // ============================================
  function showToast(message, type = 'info') {
    const icons = { success: '✅', error: '❌', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
    dom.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('removing');
      toast.addEventListener('animationend', () => toast.remove());
    }, CONFIG.TOAST_DURATION);
  }

  // ============================================
  // File Selection
  // ============================================
  function setFile(file) {
    if (!isValidFile(file)) return;
    selectedFile = file;
    dom.fileName.textContent = file.name;
    dom.fileSize.textContent = formatBytes(file.size);
    dom.filePreview.classList.add('active');
    dom.uploadBtn.disabled = false;
  }

  function clearFile() {
    selectedFile = null;
    dom.fileInput.value = '';
    dom.filePreview.classList.remove('active');
    dom.uploadBtn.disabled = true;
    dom.progressBar.classList.remove('active');
    dom.progressFill.style.width = '0%';
  }

  // ============================================
  // Drag & Drop
  // ============================================
  function initDropzone() {
    const dz = dom.dropzone;

    dz.addEventListener('click', () => dom.fileInput.click());

    dom.fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) setFile(e.target.files[0]);
    });

    ['dragenter', 'dragover'].forEach((evt) => {
      dz.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dz.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach((evt) => {
      dz.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dz.classList.remove('dragover');
      });
    });

    dz.addEventListener('drop', (e) => {
      const files = e.dataTransfer.files;
      if (files.length > 0) setFile(files[0]);
    });

    dom.removeFile.addEventListener('click', clearFile);
  }

  // ============================================
  // Upload (POST)
  // ============================================
  async function uploadFile() {
    if (!selectedFile) return;

    const btn = dom.uploadBtn;
    btn.disabled = true;
    dom.uploadBtnText.textContent = 'Convertendo...';
    dom.uploadSpinner.classList.add('active');
    dom.progressBar.classList.add('active');
    dom.progressFill.style.width = '30%';

    try {
      // Read file content as text
      const content = await selectedFile.text();

      dom.progressFill.style.width = '60%';

      const response = await fetch(`${CONFIG.API_BASE_URL}/convert`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filename: selectedFile.name,
          content: content,
        }),
      });

      dom.progressFill.style.width = '90%';

      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      dom.progressFill.style.width = '100%';

      showToast('PDF gerado com sucesso!', 'success');
      clearFile();
      // Auto-refresh the list
      setTimeout(() => fetchPDFList(), 500);

    } catch (err) {
      console.error('Upload error:', err);
      showToast(`Falha no envio: ${err.message}`, 'error');
    } finally {
      btn.disabled = false;
      dom.uploadBtnText.textContent = 'Converter para PDF';
      dom.uploadSpinner.classList.remove('active');
      setTimeout(() => {
        dom.progressBar.classList.remove('active');
        dom.progressFill.style.width = '0%';
      }, 1000);
    }
  }

  // ============================================
  // Fetch PDF List (GET)
  // ============================================
  async function fetchPDFList() {
    dom.refreshBtn.disabled = true;
    dom.refreshBtnText.textContent = 'Carregando...';
    dom.refreshSpinner.classList.add('active');

    try {
      const response = await fetch(`${CONFIG.API_BASE_URL}/files`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error(`Erro ${response.status}`);
      }

      const data = await response.json();
      renderPDFList(data.files || []);
      showToast('Lista atualizada!', 'success');

    } catch (err) {
      console.error('Fetch error:', err);
      showToast(`Erro ao buscar lista: ${err.message}`, 'error');
    } finally {
      dom.refreshBtn.disabled = false;
      dom.refreshBtnText.textContent = '🔄 Atualizar Lista';
      dom.refreshSpinner.classList.remove('active');
    }
  }

  // ============================================
  // Download PDF (GET)
  // ============================================
  async function downloadPDF(filename) {
    try {
      showToast(`Baixando ${filename}...`, 'info');

      const response = await fetch(`${CONFIG.API_BASE_URL}/files/${encodeURIComponent(filename)}`, {
        method: 'GET',
      });

      if (!response.ok) throw new Error(`Erro ${response.status}`);

      const data = await response.json();

      // Decode base64 PDF
      const byteCharacters = atob(data.data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);

      showToast(`${filename} baixado!`, 'success');

    } catch (err) {
      console.error('Download error:', err);
      showToast(`Erro no download: ${err.message}`, 'error');
    }
  }

  // ============================================
  // Render PDF List
  // ============================================
  function renderPDFList(files) {
    if (!files || files.length === 0) {
      dom.pdfList.innerHTML = `
        <li class="pdf-list__empty">
          <span class="pdf-list__empty-icon">📭</span>
          Nenhum PDF encontrado. Envie um documento para começar!
        </li>`;
      return;
    }

    dom.pdfList.innerHTML = files.map((file) => `
      <li class="pdf-item">
        <span class="pdf-item__icon">📕</span>
        <div class="pdf-item__info">
          <div class="pdf-item__name">${escapeHtml(file.name)}</div>
          <div class="pdf-item__meta">${file.size ? formatBytes(file.size) : ''} ${file.date ? '• ' + formatDate(file.date) : ''}</div>
        </div>
        <button class="pdf-item__download" data-filename="${escapeHtml(file.name)}">
          ⬇ Baixar
        </button>
      </li>
    `).join('');

    // Attach download handlers
    dom.pdfList.querySelectorAll('.pdf-item__download').forEach((btn) => {
      btn.addEventListener('click', () => downloadPDF(btn.dataset.filename));
    });
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function formatDate(dateStr) {
    try {
      return new Date(dateStr).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  }

  // ============================================
  // Mock Data (Local Testing)
  // ============================================
  let mockFiles = [];

  function addMockPDF(originalName) {
    const pdfName = originalName.replace(/\.(md|txt|markdown)$/i, '.pdf');
    mockFiles.unshift({
      name: pdfName,
      size: Math.floor(Math.random() * 500000) + 10000,
      date: new Date().toISOString(),
    });
    renderPDFList(mockFiles);
  }

  // ============================================
  // Event Listeners
  // ============================================
  function initEvents() {
    dom.uploadBtn.addEventListener('click', uploadFile);
    dom.refreshBtn.addEventListener('click', fetchPDFList);
  }

  // ============================================
  // API Health Check
  // ============================================
  async function checkAPIStatus() {
    if (CONFIG.API_BASE_URL.includes('YOUR_API')) {
      dom.statusBadge.innerHTML = `<span class="status-badge__dot"></span> Modo Local`;
      dom.statusBadge.style.background = 'rgba(245, 158, 11, 0.2)';
      dom.statusBadge.style.color = '#f59e0b';
      return;
    }

    try {
      const res = await fetch(`${CONFIG.API_BASE_URL}/files`, { method: 'GET' });
      if (res.ok) {
        dom.statusBadge.innerHTML = `<span class="status-badge__dot"></span> API Online`;
      } else {
        throw new Error();
      }
    } catch {
      dom.statusBadge.innerHTML = `<span class="status-badge__dot"></span> API Offline`;
      dom.statusBadge.style.background = 'rgba(239, 68, 68, 0.2)';
      dom.statusBadge.style.color = '#ef4444';
    }
  }

  // ============================================
  // Init
  // ============================================
  function init() {
    initDropzone();
    initEvents();
    checkAPIStatus();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
