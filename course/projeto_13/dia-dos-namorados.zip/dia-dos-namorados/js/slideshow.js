/**
 * 🌹 Slideshow — Dia dos Namorados
 * Controla slides, animações de corações, pétalas flutuantes, navegação e swipe
 */

(function () {
  'use strict';

  // --- Config ---
  const AUTO_PLAY_INTERVAL = 6000;
  const HEARTS_PER_TRANSITION = 18;
  const HEART_EMOJIS = ['❤️', '💕', '💖', '💗', '💓', '💝', '🌹', '♥️'];
  const AMBIENT_PETALS = 8;

  // --- Slide messages ---
  const MESSAGES = [
    'Meu amor, seu sorriso ilumina meu mundo inteiro. Feliz Dia dos Namorados! <span class="emoji">💕</span>',
    'Cada momento ao seu lado é um presente que guardo no coração. Te amo! <span class="emoji">🌷</span>',
    'Seu carinho é meu porto seguro. Te amo mais do que palavras podem dizer. <span class="emoji">❤️</span>',
    'Você é a melhor parte dos meus dias. Hoje e sempre, meu coração é seu. <span class="emoji">🌹</span>'
  ];

  // --- State ---
  let currentSlide = 0;
  let totalSlides = 0;
  let autoPlayTimer = null;
  let isTransitioning = false;
  let touchStartX = 0;
  let touchEndX = 0;

  // --- DOM ---
  let slides, dots, counterCurrent, counterTotal, progressBar, heartsContainer, petalsContainer;

  // --- Init ---
  function init() {
    slides = document.querySelectorAll('.slide');
    dots = document.querySelectorAll('.dot');
    counterCurrent = document.querySelector('.slide-counter__current');
    counterTotal = document.querySelector('.slide-counter__total');
    progressBar = document.querySelector('.progress-bar');
    heartsContainer = document.querySelector('.hearts-container');
    petalsContainer = document.querySelector('.petals-container');
    totalSlides = slides.length;

    if (counterTotal) counterTotal.textContent = totalSlides;

    // Inject messages
    slides.forEach((slide, i) => {
      const msgEl = slide.querySelector('.slide__message');
      if (msgEl && MESSAGES[i]) {
        msgEl.innerHTML = MESSAGES[i];
      }
    });

    // Set first slide
    goToSlide(0, false);

    // Events
    setupNavigation();
    setupDots();
    setupKeyboard();
    setupTouch();

    // Ambient petals
    spawnAmbientPetals();

    // Auto-play
    startAutoPlay();

    // Loading screen
    hideLoadingScreen();

    // Spawn initial hearts for a warm welcome
    setTimeout(() => spawnHearts(8), 1500);
  }


  // --- Go to slide ---
  function goToSlide(index, animate = true) {
    if (isTransitioning && animate) return;
    if (index < 0) index = totalSlides - 1;
    if (index >= totalSlides) index = 0;

    const previousSlide = currentSlide;
    isTransitioning = true;

    // Deactivate all
    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));

    // Activate target
    slides[index].classList.add('active');
    dots[index].classList.add('active');
    currentSlide = index;

    // Update counter
    if (counterCurrent) counterCurrent.textContent = index + 1;

    // Update progress
    updateProgress();

    // Spawn hearts on transition
    if (animate && previousSlide !== index) {
      spawnHearts();
    }

    // Unlock transition after animation
    setTimeout(() => {
      isTransitioning = false;
    }, 900);

    // Reset auto-play
    resetAutoPlay();
  }

  function nextSlide() { goToSlide(currentSlide + 1); }
  function prevSlide() { goToSlide(currentSlide - 1); }

  // --- Progress bar ---
  function updateProgress() {
    if (!progressBar) return;
    const pct = ((currentSlide + 1) / totalSlides) * 100;
    progressBar.style.width = pct + '%';
  }

  // --- Navigation arrows ---
  function setupNavigation() {
    const prevBtn = document.getElementById('nav-prev');
    const nextBtn = document.getElementById('nav-next');
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);
    if (nextBtn) nextBtn.addEventListener('click', nextSlide);
  }

  // --- Dots ---
  function setupDots() {
    dots.forEach((dot, i) => {
      dot.addEventListener('click', () => goToSlide(i));
    });
  }

  // --- Keyboard ---
  function setupKeyboard() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); nextSlide(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); prevSlide(); }
    });
  }

  // --- Touch / Swipe ---
  function setupTouch() {
    const container = document.querySelector('.slideshow');
    if (!container) return;

    container.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    container.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
    }, { passive: true });
  }

  function handleSwipe() {
    const diff = touchStartX - touchEndX;
    const threshold = 50;
    if (Math.abs(diff) < threshold) return;
    if (diff > 0) nextSlide();
    else prevSlide();
  }

  // --- Auto-play ---
  function startAutoPlay() {
    autoPlayTimer = setInterval(nextSlide, AUTO_PLAY_INTERVAL);
  }

  function resetAutoPlay() {
    clearInterval(autoPlayTimer);
    startAutoPlay();
  }

  // --- Heart animations ---
  function spawnHearts(count) {
    if (!heartsContainer) return;
    const total = count || HEARTS_PER_TRANSITION;

    for (let i = 0; i < total; i++) {
      const heart = document.createElement('span');
      heart.classList.add('heart');
      heart.textContent = HEART_EMOJIS[Math.floor(Math.random() * HEART_EMOJIS.length)];

      const leftPos = Math.random() * 100;
      const size = 0.8 + Math.random() * 1.5;
      const duration = 3 + Math.random() * 3;
      const delay = Math.random() * 1.2;

      heart.style.left = leftPos + '%';
      heart.style.fontSize = size + 'rem';
      heart.style.setProperty('--duration', duration + 's');
      heart.style.setProperty('--delay', delay + 's');

      heartsContainer.appendChild(heart);

      // Remove after animation
      setTimeout(() => {
        if (heart.parentNode) heart.parentNode.removeChild(heart);
      }, (duration + delay) * 1000 + 500);
    }
  }

  // --- Ambient floating petals ---
  function spawnAmbientPetals() {
    if (!petalsContainer) return;

    // Check for reduced motion preference
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    for (let i = 0; i < AMBIENT_PETALS; i++) {
      const petal = document.createElement('span');
      petal.classList.add('petal');

      const leftPos = Math.random() * 100;
      const size = 6 + Math.random() * 12;
      const duration = 10 + Math.random() * 15;
      const delay = Math.random() * 8;
      const rotation = Math.random() * 360;

      petal.style.left = leftPos + '%';
      petal.style.width = size + 'px';
      petal.style.height = size + 'px';
      petal.style.setProperty('--petal-duration', duration + 's');
      petal.style.setProperty('--petal-delay', delay + 's');
      petal.style.transform = `rotate(${rotation}deg)`;
      petal.style.opacity = '0';

      petalsContainer.appendChild(petal);
    }
  }

  // --- Loading screen ---
  function hideLoadingScreen() {
    const loading = document.querySelector('.loading-screen');
    if (!loading) return;

    // Wait for images to finish loading (or timeout)
    const images = document.querySelectorAll('.slide__image');
    let loaded = 0;
    const total = images.length;

    function checkLoaded() {
      loaded++;
      if (loaded >= total) {
        setTimeout(() => loading.classList.add('hidden'), 600);
      }
    }

    images.forEach(img => {
      if (img.complete) {
        checkLoaded();
      } else {
        img.addEventListener('load', checkLoaded);
        img.addEventListener('error', checkLoaded);
      }
    });

    // Fallback timeout
    setTimeout(() => loading.classList.add('hidden'), 3500);
  }

  // --- Boot ---
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
