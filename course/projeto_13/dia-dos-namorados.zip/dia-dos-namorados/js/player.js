/**
 * 🎵 Player de Música — Dia das Mães
 * Controla reprodução de áudio com botão play/mute
 */

(function () {
  'use strict';

  // ============================================================
  // 🔧 CONFIGURAÇÃO: O ID do vídeo do YouTube extraído do link.txt
  // ============================================================
  const YOUTUBE_VIDEO_ID = 'yW5l7dbH664'; // ID do vídeo https://music.youtube.com/watch?v=yW5l7dbH664

  let ytPlayer = null;
  let isPlaying = false;
  let musicBtn = null;
  let iconEl = null;
  let isPlayerReady = false;

  function init() {
    musicBtn = document.getElementById('music-btn');
    iconEl = musicBtn ? musicBtn.querySelector('.music-btn__icon') : null;

    if (!musicBtn) return;

    // Load YouTube IFrame API
    const tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    window.onYouTubeIframeAPIReady = function() {
      // Create a hidden div for the player
      const playerDiv = document.createElement('div');
      playerDiv.id = 'yt-player-hidden';
      playerDiv.style.display = 'none';
      document.body.appendChild(playerDiv);

      ytPlayer = new YT.Player('yt-player-hidden', {
        height: '0',
        width: '0',
        videoId: YOUTUBE_VIDEO_ID,
        playerVars: {
          'autoplay': 0,
          'controls': 0,
          'loop': 1,
          'playlist': YOUTUBE_VIDEO_ID
        },
        events: {
          'onReady': onPlayerReady,
          'onStateChange': onPlayerStateChange
        }
      });
    };

    musicBtn.addEventListener('click', toggleMusic);
  }

  function onPlayerReady(event) {
    isPlayerReady = true;
    ytPlayer.setVolume(50);
  }

  function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.PLAYING) {
      updateUI(true);
    } else if (event.data === YT.PlayerState.PAUSED || event.data === YT.PlayerState.ENDED) {
      updateUI(false);
    }
  }

  function toggleMusic() {
    if (!isPlayerReady || !ytPlayer) {
      console.info('🎵 Player do YouTube ainda não está pronto.');
      animateButton();
      return;
    }

    if (isPlaying) {
      ytPlayer.pauseVideo();
    } else {
      ytPlayer.playVideo();
    }
  }

  function updateUI(playing) {
    isPlaying = playing;

    if (!musicBtn || !iconEl) return;

    if (playing) {
      musicBtn.classList.add('playing');
      iconEl.textContent = '🔊';
      musicBtn.setAttribute('aria-label', 'Pausar música');
      musicBtn.title = 'Pausar música';
    } else {
      musicBtn.classList.remove('playing');
      iconEl.textContent = '🎵';
      musicBtn.setAttribute('aria-label', 'Tocar música');
      musicBtn.title = 'Tocar música';
    }
  }

  function animateButton() {
    if (!musicBtn) return;
    musicBtn.style.transform = 'scale(1.2)';
    setTimeout(() => { musicBtn.style.transform = ''; }, 200);
  }

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
