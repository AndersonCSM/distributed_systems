const express = require('express');
const cors = require('cors');
const { CognitoJwtVerifier } = require('aws-jwt-verify');

const app = express();
app.use(cors());
app.use(express.json());

// Configuração do verificador JWT do Cognito
// Substitua pelos seus dados do Cognito
const verifier = CognitoJwtVerifier.create({
  userPoolId: "us-east-1_XXXXX", // Ex: us-east-1_abcd1234
  tokenUse: "access",
  clientId: "XXXXXXXXXXXXXXXXXXXXXXXXX", // Ex: 1234567890abcdef1234567890
});

// Rota Desprotegida (Pública)
app.get('/api/publica', (req, res) => {
  res.json({ message: "Esta é uma rota pública." });
});

// Middleware de Autorização do Cognito
const cognitoAuthorizer = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ 
      error: "Falha de autorização", 
      message: "access_token não está presente ou em formato inválido." 
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = await verifier.verify(token);
    req.user = payload; // Salva o payload do usuário na requisição
    next();
  } catch (err) {
    console.error("Token inválido:", err);
    return res.status(403).json({ 
      error: "Falha de autorização", 
      message: "O access_token fornecido é inválido ou expirou." 
    });
  }
};

// Rota Protegida pelo Autorizador Cognito
app.get('/api/protegida', cognitoAuthorizer, (req, res) => {
  res.json({ 
    message: "Sucesso! Rota protegida acessada com sucesso.", 
    evento: "Dia dos Namorados",
    user_id: req.user.sub
  });
});

const serverless = require('serverless-http');
module.exports.handler = serverless(app);
